/*!
    \file    systick.c
    \brief   the systick configuration file

      \version 2019-06-05, V1.0.0, firmware for GD32VF103
*/

/*
    Copyright (c) 2019, GigaDevice Semiconductor Inc.

    All rights reserved.

    Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

    1. Redistributions of source code must retain the above copyright notice, this 
       list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright notice, 
       this list of conditions and the following disclaimer in the documentation 
       and/or other materials provided with the distribution.
    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software without 
       specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE.
*/

#include "gd32vf103.h"
#include "systick.h"

void systick_config(void)
{
	/* ---this comment is added by mzhu from Nuclei ISA doc
	 * The TIMER implements a 64-bit register mtimecmp, which is composed of {mtimecmp_hi, mtimecmp_lo}.
	 * This register is used as the comparison value of the timer.
	 * If the value of mtime is greater than the value of mtimecmp,
	 * then a timer interrupt is generated.
	 *
	 */
	eclic_global_interrupt_enable();
    *(uint64_t*)(TIMER_CTRL_ADDR + TIMER_MTIMECMP) = TIMER_FREQ / 250;
    //--if Generate 100 interrupt each second? too slow --mzhu
    //--1000 per second may be high for host to consume it
    //--tried. 500 is best result
    //---at 500/second and each report contain 64 bytes,  there are 20% reports will be missed by the host.
    //---at 500/second and each report contain 44 bytes,  there are 18.3% reports will be missed by the host.
    //---at 500/second and each report contain 24 bytes,  there are 12.3% reports will be missed by the host.
    //I used my VC program to count it.-----mzhu  3/31/2021
    //4/15/2021 tried 250/second, it is much better than 500/second regarding the lose of reports caputured by host.
    eclic_set_nlbits(ECLIC_GROUP_LEVEL2_PRIO2);
    eclic_irq_enable(CLIC_INT_TMR, 3, 3);
    *(uint64_t*)(TIMER_CTRL_ADDR + TIMER_MTIME) = 0;  //MTIME register be cleared to 0;---mzhu
}
